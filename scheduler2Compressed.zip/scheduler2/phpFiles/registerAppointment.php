<?php   if(session_status() !== PHP_SESSION_ACTIVE) {session_start();}
    include("../serverFiles/_dbConnection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link type="text/css" rel="stylesheet" href="../cssFiles/homeOrganizer.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title> 
</head>
<body>   
<div class="header">
            <div><img src="../mediaFiles/schedulerlogo.jpeg" class="logoimg"></div>
            <h1>Welcome to the Smart Scheduler!</h1>
        </div>
        <div class="navbar">
            <a href=""><?php if(isset($_SESSION['username'])){echo "Hello ".$_SESSION['username'];} ?></a>
            <a href="logout.php"                    >LogOut</a>
            <a href="userAppointments.php"          >Check Appointment's</a>
            <a href=""                              >Contact us</a>
            <a href=""                              >Carrers</a>
        </div>
    <div class="appointmentForm" id="appointmentForm" style="border:5px;background-colur:blue">
            
        <form class="aptform" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <tabel>
                <tr>
                    <td>
                        AppointmentDate:
                    </td>
                    <td>
                        <input type="date" id="txtDate" min="<?php echo date("Y-m-d"); ?>" name="date"></input><br><br>
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Time :
                    </td>
                    <td>
                        <input  type="time" name="starttime" ></input> &nbsp  To &nbsp
                    </td>
                    <td>
                        <input  type="time" name="stoptime" ></input><br><br>
                    </td>
                </tr>
                <tr>
                    <td>
                        Remark :
                    </td>
                    <td>
                        <input  type="text" name="remark" placeholder="something that you'd like to tell them"></input><br><br>
                    </td>
                </tr>
                <tr>
                    <td>
                        Enter Number: 
                    </td>
                    <td>
                        <button id="oid" onclick="myFunction()" src="../mediaFiles/schedulerlogo.jpeg">generatenumber</button><br><br><input  type="text" name="oid" required></input><br><br>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" name="Schedule" value="Shedule">
                    </td>
                    <td>
                        <button onclick=backtohome()>Go Back</button>
                    </td>
                </tr>
        </form>


    </div>

            <?php
                echo '<script>localStorage.getItem("oid");</script>';
                if ($_SERVER["REQUEST_METHOD"] == "GET") {
                    $uid=$oid=$starttime=$endtime=$status="";
                    if(isset($_SESSION['userid'])){
                        $uid = $_SESSION['userid'];
                    }                
                    $date=$remark="";
                    if(isset($_GET['date']) and isset($_GET['remark'])){
                        $date   = $_GET['date'];
                        $remark = $_GET['remark'];
                        $oid    = $_GET['oid'];
                        $starttime= $_GET['starttime'];
                        $endtime= $_GET['stoptime'];
                        $query="Insert INTO appointments (uid, oid, date, remark, aptstarttime, aptendttime, status) VALUES ('$uid','$oid','$date','$remark', '$starttime', '$endtime', 'Pending')";
                        $query2="DELETE FROM appointments WHERE date<CURDATE() or status='Reject'";
                        if(!$dbConnection->query($query) or !$dbConnection->query($query2)){
                            echo $dbConnection->error;
                        }
                    }
                }
            ?>

            <script>
                function backtohome(){
                    window.location.href=("../phpFiles/userhome.php");
                }
                function myFunction() {
                    document.getElementById("oid").innerHTML = localStorage.getItem("oid");
                }
            </script>
</body>
</html>