<?php
    include("../serverFiles/_dbConnection.php");
    $aid=$_POST['aptid'];
    $query="UPDATE appointments set status='Reject' where aid='$aid'";
    if(!$dbConnection->query($query)){
        echo $dbConnection->error;
    }
    else{
        header('location: organizerhome.php');
    }
?>