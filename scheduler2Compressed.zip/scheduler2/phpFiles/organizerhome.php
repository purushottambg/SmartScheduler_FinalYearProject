<?php    if(session_status() !== PHP_SESSION_ACTIVE) {session_start();}
    include("../serverFiles/_dbConnection.php");
    if(isset($_SESSION['ousername'])){
        $oname = $_SESSION['ousername'];
    }else{$oname="";}
    $query = "select o.organizerid, u.userid, u.username, u.phone, u.email, ou.aid, ou.date, ou.aptstarttime, ou.aptendttime, ou.remark from users u, organizers o, appointments ou where u.userid=ou.uid and o.organizerid=ou.oid and o.organizername='$oname'";
    $result = $dbConnection->query($query);
    if($result){
        $numberOfRecords=$result->num_rows;
    }
    else{
        echo "failed to load".$dbConnection->error;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <link type="text/css" rel="stylesheet" href="../cssFiles/homeOrganizer.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organiser Dashboard</title> 
</head>
<body>   
    <div class="header">
        <div><img src="../mediaFiles/schedulerlogo.jpeg" class="logoimg"></div>
            <h1>Welcome to the Smart Scheduler!</h1>
        </div>
        <div class="navbar">
            <a href=""><?php if(isset($_SESSION['ousername'])){echo "Hello ".$_SESSION['ousername'];} ?></a>
            <a href="logout.php">LogOut</a>
            <a href="">info</a>
            <a href="">Contact us</a>
            <a href="">Carrers</a>
            <div class="searchbutton">
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST"> 
                    <input type="text" name="organizerName" placeholder="search for an appointment" style="height: 38px;">
                    <button type="submit" class="search">Search</button>
                <form>
            </div>
        </div>
    <div class="Organization" id="appointments">
        <?php
            if($_SERVER['REQUEST_METHOD']=="POST"){
                $searchUser = $_POST['organizerName'];
                $searchUserQuery = "select o.organizerid, u.userid, u.username, u.phone, u.email, ou.aid, ou.date, ou.aptstarttime, ou.aptendttime, ou.remark from users u, organizers o, appointments ou where u.userid=ou.uid and o.organizerid=ou.oid and u.username='$searchUser' and o.organizername='$oname'";
                $searchUserResponse = $dbConnection->query($searchUserQuery);
                if($searchUserResponse){
                    while($searchresp = $searchUserResponse->fetch_assoc()){
                        $aid      =   $searchresp['aid'];
                        $uname    =   $searchresp['username'];
                        $email    =   $searchresp['email'];
                        $contact  =   $searchresp['phone'];
                        $remark   =   $searchresp['remark'];
                        $starttime=   $searchresp['aptstarttime'];
                        $date     =   $searchresp['date'];
                        $endtime  =   $searchresp['aptendttime'];
                echo '
                    <div class="container" id="container">
                    <p class="title"  id="title"> '.$uname.' </p>
                    <p class="sector"    >  '.$email.' </p>
                    <p class="estd"      > '.$contact.'</p>
                    <p class="email"     >  '.$date.  '</p>
                    <p class="email"     >  '.$starttime.' - '.$endtime. '</p>
                    <p class="email"     >  '.$remark.  '</p>
                    <button id='.$aid.' onclick=accept(this.id)>Confirm</button> &nbsp&nbsp&nbsp&nbsp<button id='.$aid.' onclick=reject(this.id)>Reject</button>
                    </div>
                    <div id="result">
                    </div>
                ';
                    }
                }
                else{
                    echo $dbConnection->error;
                }
            }else{
                echo $dbConnection->error;
            }
            while($record = $result->fetch_assoc()){
                $aid      =   $record['aid'];
                $uname    =   $record['username'];
                $email    =   $record['email'];
                $contact  =   $record['phone'];
                $remark   =   $record['remark'];
                $starttime=   $record['aptstarttime'];
                $date     =   $record['date'];
                $endtime  =   $record['aptendttime'];
                echo '
                    <div class="container" id="container">
                    <p class="title"  id="title"> '.$uname.' </p>
                    <p class="sector"    >  '.$email.' </p>
                    <p class="estd"      > '.$contact.'</p>
                    <p class="email"     >  '.$date.  '</p>
                    <p class="email"     >  '.$starttime.' - '.$endtime. '</p>
                    <p class="email"     >  '.$remark.  '</p>
                    <button id='.$aid.' onclick=accept(this.id)>Confirm</button> &nbsp&nbsp&nbsp&nbsp<button id='.$aid.' onclick=reject(this.id)>Reject</button>
                    </div>
                    <div id="result">
                    </div>
                ';
            }
        ?>
        <script>
            function accept(id) {
                alert('appoinment confirmed');
                var val1 = id;
                $.ajax({
                    type: 'POST',
                    url: 'acceptappointments.php',
                    data: { aptid: val1 },
                    success: function(response) {
                        
                    }
                });
            };
            function reject(id) {
                alert('appoinment canceled');
                var val1 = id; 
                $.ajax({
                    type: 'POST',
                    url: 'deletappointments.php',
                    data: { aptid: val1 },
                    success: function(response) {
                        
                    }
                });
            };
        </script>
    </div> 
</body>
</html>