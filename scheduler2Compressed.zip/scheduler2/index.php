<?php session_start()?>
<style>
    <?php include 'cssFiles/index.css'; ?>
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Scheduler</title>  
    
</head>
<body>   
        <div class="header" style="background:silver;">
            <div><img src="mediaFiles/schedulerlogo.jpeg" class="logoimg"></div>
            <h1>Welcome to the Smart Scheduler!</h1>
        </div>
        <div class="navbar">
            <a href="navFiles/organizations.php">See Organisation's</a>
            <a href="serverFiles/registerUser.php"      >SignUP</a>
            <a href="navFiles/info.html"              >info</a>
            <a href="navFiles/contact.html"              >Contact us</a>
        </div>
        <div class="body">
            <div class="data">
                <p>This WebApplication is developed so we could help People. In this pandemic we all must follw
                    all the government guidlines which help us to stay healthy in thud situation. this app will play key role to stop 
                    the spread of the corona virus and save your valuable time. to stop the further spread of virus we all are trying to avoid the crowdy places so no one
                    get infected, So let's see how this app work.
                </p>
                <ol style="list-style-type:lower-alpha ;">
                    <li>
                        First SignUp as user or organizer
                    </li>
                    <li>
                        Fill the required data
                    </li>
                    <li>
                        Choose the organization and get <br>appointment (for user)
                    </li>
                    <li>
                        Check status and visit organization 
                    </li>
                </ol>
            </div>
            <div class="login">
                <h2 align="center">LogIn </h2>
                    <table >
                    <form action="serverFiles/login.php" method="post">  <!--serverFiles/login.php -->
                        <tr class="row">
                            <td>    <p class="oformtext">Username:</p>    </td>
                            <td>    <input type="text"  placeholder="Username" name="username" minlength="6" maxlength="20" pattern="[A-Za-z]{1,15}" required></td>
                        </tr>
                        <tr class="row">
                            <td>    <p class="oformtext">Password:</p>    </td>
                            <td>    <input type="password"  placeholder="Password" name="password" minlength="6" maxlength="12" required> </td>
                        </tr>
                        <tr class="row">
                                <td colspan=2 >    <input type="submit" style="background-color:silver;width: 250px;" value="LogIn"></td>
                        </tr>
                    </form>
                    </table>               
                Not regeistered Yet?<u><a href="serverFiles/registerUser.php">  Register Now</a></u>
                <div class="registered"><p class='error'>
                    
                    <?php
                        if(isset($_SESSION['error'])){
                            echo $_SESSION['error'];
                        }
                    ?>
                </p>
                </div>
            </div>
        </div>
        <footer class="footer">
            <p>Company © W3docs. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
<script>

</script>