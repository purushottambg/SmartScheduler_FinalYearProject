<?php   if(session_status() !== PHP_SESSION_ACTIVE) {session_start();}
    include("../serverFiles/_dbConnection.php");
    $query = "SELECT * FROM organizers";
    $result = $dbConnection->query($query);
    if($result){
        $numberOfRecords=$result->num_rows;
    }
    else{
        echo $dbConnection->error;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link type="text/css" rel="stylesheet" href="../cssFiles/homeOrganizer.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title> 
</head>
<body>   
        <div class="header">
            <div><img src="../mediaFiles/schedulerlogo.jpeg" class="logoimg"></div>
            <h1>Welcome to the Smart Scheduler!</h1>
        </div>
        <div class="navbar">
            <a href="../index.php">Home Page</a>
            <a href="../navFiles/organizations.php">See Organisation's</a>
            <a href="../serverFiles/registerUser.php"      >SignUP</a>
            <a href="../navFiles/info.html"              >info</a>
            <a href="../navFiles/contact.html"              >Contact us</a>
            <div class="searchbutton">
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST"> 
                <input type="text" name="organizerName" placeholder="search for an appointment" style="height: 38px;">
                <button type="submit" class="search">Search</button>
                <form>
            </div>
        </div>
    <div class="Organization" id="Organization">
    <?php
        if($_SERVER['REQUEST_METHOD']=="POST"){
            $searchOrganizer = $_POST['organizerName'];
            $searchOrganizerQuery="SELECT * FROM organizers WHERE organizername='$searchOrganizer'";
            $searchResponse = $dbConnection->query($searchOrganizerQuery);
            if($searchResponse){
                while($searchResp   =   $searchResponse->fetch_assoc()){
                    $title   =$searchResp['organizername'];
                    $oid     =$searchResp['organizerid'];
                    $sector  =$searchResp['sector'];
                    $contact =$searchResp['phone'];
                    $email   =$searchResp['email'];
                    $address =$searchResp['address'];
                    $estd    =$searchResp['date'];
                echo '
                    <div class="container" id="container">
                    <p class="title"   id="title"  > '.$title.'</p>
                    <p class="contact"   >  '.$contact.'</p>
                    <p class="email"     >  '.$email.  '</p>
                    <p class="address"   >  '.$address.'</p>
                    <p class="estd"      >  '.$estd.  '</p>
                    </div>
                ';
                }
            }
        }
        while($record = $result->fetch_assoc()){
            $title   =$record['organizername'];
            $oid     =$record['organizerid'];
            $_SESSION['organizerid']=$oid;
            $sector=$record['sector'];
            $contact=$record['phone'];
            $email=$record['email'];
            $address=$record['address'];
            $estd=$record['date'];
            echo '
                <div class="container" id="container">
                <p class="title"   id="title"  > '.$title.'</p>
                <p class="contact"   >  '.$contact.'</p>
                <p class="email"     >  '.$email.  '</p>
                <p class="address"   >  '.$address.'</p>
                <p class="estd"      >  '.$estd.  '</p>
            </div>
            ';
        }
    ?>
    </div>
</body>
</html>