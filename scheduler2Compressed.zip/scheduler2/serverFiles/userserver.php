<?php
    include "../serverFiles/_dbConnection.php";
    $name=$sector=$contact=$email=$addres=$about=$pass1=$pass2=$pass3="";
    if($_SERVER['REQUEST_METHOD']=='POST'){          //Registration for user
            $name = $_POST['username'];
            $email= $_POST['email'];
            $phone= $_POST['phone'];
            $pass1= password_hash($_POST['password'], PASSWORD_DEFAULT);
            
            $query = "INSERT INTO users (username,email,phone,password) VALUES ('$name','$email','$phone','$pass1')";
            if($dbConnection->query($query)){
                session_start();
                $_SESSION['username']=$name;
                header('location: ../phpFiles/userhome.php');
            }else{
                echo $dbConnection->error;
            }
    }
?>