<?php
    if($_SERVER['REQUEST_METHOD']=='POST'){
        $content="";
        $content = $_POST['content'];
        echo "Looking For ".$content." in our database";
    }
?>