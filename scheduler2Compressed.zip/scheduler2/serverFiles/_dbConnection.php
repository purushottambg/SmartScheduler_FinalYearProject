<?php
    $server="locahost";
    $user="root";
    $dbName="scheduler2";
    $pass="";
    $dbConnection=new mysqli('localhost','root','','scheduler2');
    if(!$dbConnection){
        echo "Failed to connect database Error: ";
    }
?>