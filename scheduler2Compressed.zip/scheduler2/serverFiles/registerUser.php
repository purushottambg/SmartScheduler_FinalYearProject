<style>
    <?php include '../cssFiles/homeOrganizer.css'; ?>
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register as a User</title>
    <link rel="shortcut icon" href="schedulerlogo.jpeg" type="image/x-icon">
</head>
<body>   
        <div class="header">
            <div><img src="../mediaFiles/schedulerlogo.jpeg" class="logoimg"></div>
            <h1>Welcome to the Smart Scheduler!</h1>
        </div>
        <div class="navbar">
            <a href="../index.php">Home Page</a>
            <a href="../navFiles/organizations.php">See Organisation's</a>
            <a href="../serverFiles/registerUser.php"      >SignUP</a>
            <a href="../navFiles/info.html"              >info</a>
            <a href="../navFiles/contact.html"              >Contact us</a>
        </div>
        <div class="body" style="display: flex;flex-wrap: wrap;">     <!--for entire body-->
            <div class="data" style="flex: 50%;">
            <p>This WebApplication is developed so we could help People. In this pandemic we all must follw
                    all the government guidlines which help us to stay healthy in this situation. this app will play key role to stop 
                    the spread of the corona virus and save your valuable time. to stop the further spread of virus we all are trying to avoid the crowdy places so no one
                    get infected, So let's see how this app work.
                </p>
                <ol style="list-style-type:lower-alpha ;">
                    <li>
                        First SignUp as user
                    </li>
                    <li>
                        Goto Home Page
                    </li>
                    <li>
                        Search for organizations
                    </li>
                    <li>
                        Ask for an appointment, mention date and time
                    </li>
                    <li>
                        Visit on time, if appointment Confirmed
                    </li>
                </ol>
            </div>
            <div class="login" style="flex: 50%;">
                <h2 align="center"> User SignUP </h2>
                <form action="userserver.php" method="POST">
                    <table>
                        <tr>
                            <td>
                                <p class="uformtext">   username: </p>
                            </td>
                            <td>
                                <input type="text" placeholder="as @Username" name="username" required minlength="6" maxlength="20" pattern="[A-Za-z]{1,15}"></lable><br><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p class="uformtext">Email:</p>
                            </td>
                            <td>
                                <input type="email" placeholder="xxxxX@gmail.com" name="email" required></lable><br><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p class="uformtext">Contact:</p>
                            </td>
                            <td>
                                <input type="tel" placeholder="+91 0123456789" name="phone" minlength="13" maxlength="13" pattern="[+]{1}[0-9]{11,14}"  required ></lable><br><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <p class="uformtext">Password:</p>
                            </td>
                            <td>
                                <input type="password" placeholder="Enter Password" pattern="[A-Za-z]{1,15}" name="password" required></lable><br><br>
                            </td>
                        </tr>
                    </table>   
                        <button type="submit" style="background-color:silver;width: 250px;">Sign Up</submit></b>
                        <button type="button" style="background-color:silver;float:right;width: 100px;height: 40px;"><u><a href="registerOraganiser.php">Register as Organiser   </a></u>
                </form>
                <div>
                <?php
                    if(isset($_SESSION['error'])){
                        echo $_SESSION['error'];
                    }
                ?>
            </div>
            </div>
        </div>
    <footer class="footer">
            <p>Company © W3docs. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>