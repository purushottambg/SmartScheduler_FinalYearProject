<?php
    $username="";
    $password="";
    include("../serverFiles/_dbConnection.php");
    if ( $_SERVER["REQUEST_METHOD"]=="POST"){                           //form data retrieval
        $username=$_POST['username'];
        $password=$_POST['password'];
    $insertQuery="SELECT * FROM users WHERE username='$username'"; //query to be performed
    $checkUser=$dbConnection->query($insertQuery);
    $insertQuery2="SELECT * FROM organizers WHERE organizername ='$username' "; //query to be performed
    $checkUser2=$dbConnection->query($insertQuery2);
    if( $checkUser){
        $rowcnt = $checkUser->num_rows;
        if($rowcnt > 0 ){
            while($users = $checkUser->fetch_assoc()){
                if(password_verify($password,$users['password'])){
                    session_start();
                    $_SESSION['username']=$username;
                    header('location: ../phpFiles/userhome.php');
                }
            }
        }
        else if($checkUser2){
            $rowcnt = $checkUser2->num_rows;
            if($rowcnt > 0 ){
                session_start();
                $_SESSION['ousername']=$username;
                header('location: ../phpFiles/organizerhome.php');
            }
            else{
                session_start();
                $_SESSION['error']="Invalid Credentials";
                header('location: ../index.php');
            }
        }
    }
}
?>