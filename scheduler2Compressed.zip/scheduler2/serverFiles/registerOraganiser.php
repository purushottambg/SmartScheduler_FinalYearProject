<!DOCTYPE html>
<html lang="en">
<head>
    <link type="text/css" rel="stylesheet" href="../cssFiles/homeOrganizer.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register as a Organiser</title>
    <link rel="shortcut icon" href="schedulerlogo.jpeg" type="image/x-icon">
</head>
<body>   
        <div class="header">
            <div><img src="../mediaFiles/schedulerlogo.jpeg" class="logoimg"></div>
            <h1>Welcome to the Smart Scheduler!</h1>
        </div>
        <div class="navbar">
            <a href="../navFiles/organizations.php"         >See Organisation's</a>
            <a href="../serverFiles/registerUser.php"       >SignUP</a>
            <a href="../navFiles/info.html"                 >info</a>
            <a href="../navFiles/contact.html"              >Contact us</a>
        </div>
        <div class="body" style="display: flex;flex-wrap: wrap;">     <!--for entire body-->
            <div class="data" style="flex: 50%;">
            <p>This WebApplication is developed so we could help People. In this pandemic we all must follw
                    all the government guidlines which help us to stay healthy in thud situation. this app will play key role to stop 
                    the spread of the corona virus and save your valuable time. to stop the further spread of virus we all are trying to avoid the crowdy places so no one
                    get infected, So let's see how this app work.
                </p>
                <ol style="list-style-type:lower-alpha ;">
                    <li>
                        First SignUp as organizer
                    </li>
                    <li>
                        Goto Home Page
                    </li>
                    <li>
                        Check the User's appointment Requset
                    </li>
                    <li>
                        Respond to appointment Request's 
                    </li>
                </ol>
            </div>
            <div class="login" style="flex: 50%;">
                <h2 align="center">Organization SignUp </h2>
                <form action="organizerserver.php" method="POST">
                    <table>
                        <tr class="row">
                            <td>    <p class="oformtext">Username:</p>    </td>
                            <td>    <input type="text" placeholder="username" name="uname" minlength="6" maxlength="20" pattern="[A-Za-z]{1,15}" required></td>
                        </tr>
                        <tr class="row">
                            <td>    <p class="oformtext">Sector:</p>    </td>
                            <td>    <input type="text" placeholder="i.e. Bank, Hopsital" name="sector" maxlength="40" required> </td>
                        </tr>
                        <tr class="row">
                            <td>    <p class="oformtext">Phone:</p>    </td>
                            <td>    <input type="tel" placeholder="+91 0123456789" name="contact" minlength="13" maxlength="13" pattern="[+]{1}[0-9]{11,14}"  required></td>
                        </tr>
                        <tr>
                            <td>    <p class="oformtext">Email:</p>    </td>
                            <td>    <input type="email" placeholder="as @Username" name="email" required></td>
                        </tr>
                        <tr>
                            <td>    <p class="oformtext">Address:</p>    </td>
                            <td>    <input type="text" placeholder="Full Address" name="address" required></td>
                        </tr>
                        <tr>
                            <td>    <p class="oformtext">Password:</p>    </td>
                            <td>    <input type="password" placeholder=" Enter Password" pattern="[A-Za-z]{1,15}" name="Password1" minlength="6" maxlength="12" required></td>
                        </tr>                        
                    </table>
                        <button type="submit" style="background-color:silver;width: 250px;">Sign Up</submit></b>
                        <button type="button" style="background-color:silver;float:right;width: 100px;height: 40px;"><u><a href="../index.php">Already User</a></u></submit>
                </form>
                <div>
                <?php
                    if(isset($_SESSION['error'])){
                        echo $_SESSION['error'];
                    }
                ?>
            </div>
            </div>
        </div>
    <footer class="footer">
        <p>Company © W3docs. All rights reserved.</p>
    </footer>
</body>
</html>