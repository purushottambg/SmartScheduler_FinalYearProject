<?php
    include "../serverFiles/_dbConnection.php";
    $name=$sector=$contact=$email=$addres=$about=$pass1=$pass2=$pass3="";
    if($_SERVER['REQUEST_METHOD']=='POST'){     //Registration for Organization
            $uname   = $_POST['uname'];
            $sector = $_POST['sector'];
            $contact= $_POST['contact'];
            $email  = $_POST['email'];
            $addres = $_POST['address'];
            $pass1  = $_POST['Password1'];
            $date = date("Y/m/d");
            $query = "INSERT INTO organizers (organizername,sector,phone,email,address,date,password) 
            VALUES ('$uname','$sector','$contact','$email','$addres','$date','$pass1')";
            if($dbConnection->query($query)){ 
                session_start();
                $_SESSION['ousername']=$uname;
                header('location: ../phpFiles/organizerhome.php');
            }else{
                echo $dbConnection->error;
            }
    }
?>